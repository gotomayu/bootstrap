/*global $*/

$('[data-toggle=tooltip]').tooltip();